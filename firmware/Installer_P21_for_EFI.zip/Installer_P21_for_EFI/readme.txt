Use this installer for EFI systems
