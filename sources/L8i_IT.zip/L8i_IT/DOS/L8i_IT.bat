
sasflash -o -f L8i_IT.fw -b mptsas.rom