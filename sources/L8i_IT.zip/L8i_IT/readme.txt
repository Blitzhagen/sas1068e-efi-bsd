
 SMC Firmware update files for 1068E(B3) controller chip:
    Firmware version 1.30.00.00
    BIOS version 6.30.00.00

 1) Unzip and choose the setup folder according to the running OS.
 2) In DOS OS, run the batch file in the Dos setup folder.
 3) For Windows OS, go into the Command Prompt window and run the batch file in the Windows setup folder.
 4) For Linux OS, go in Terminal window and run the batch file in the Linux setup folder.
