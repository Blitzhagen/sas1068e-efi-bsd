
./sasflash.exe -o -f L8i_IT.fw -b mptsas.rom